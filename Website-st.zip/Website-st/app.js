const express=require("express");
const bodyParser=require("body-parser");
const app=express();
const axios = require('axios');



app.set("view engine","ejs");
app.use(express.static("public"));
app.use(bodyParser.urlencoded({
  extended: true
}));

app.get("/",function(req,res){
  res.render('home')
});

app.get("/json",function(req,res){
  axios.get('http://127.0.0.1:8000')
      .then(response => {
        chartdata=response.data.data;
        res.send(chartdata);
      })
      .catch(error => {
        console.log(error);
        return error
      });
});




app.listen(3000,function(){
  console.log("Website Server on Port 3000");
});
