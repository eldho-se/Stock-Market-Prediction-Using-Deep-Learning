// Make an HTTP request to the /json/ route of our express server:
const log = console.log;

const chartProperties = {
  width:1271,
  height:536,
  timeScale:{
    timeVisible:true,
    secondsVisible:false,
  }
}

const domElement = document.getElementById('tvchart');
const chart = LightweightCharts.createChart(domElement,chartProperties);
const candleSeries = chart.addCandlestickSeries();
// cdata=[{'time': 1656084240, 'open': 853.3, 'high': 853.5, 'low': 853.0, 'close': 853.0}, {'time': 1656084300, 'open': 853.0, 'high':
// 853.9, 'low': 852.6, 'close': 853.45}, {'time': 1656084360, 'open': 853.8, 'high': 854.0, 'low': 853.2, 'close': 853.5}, {'time': 1656084420, 'open': 853.5, 'high': 853.8, 'low': 853.35, 'close':
// 853.7}, {'time': 1656084480, 'open': 853.7, 'high': 853.95, 'low': 853.1, 'close': 853.5}, {'time': 1656084540, 'open': 853.45, 'high': 853.7, 'low': 851.1, 'close': 852.0}]
// log(cdata);
// candleSeries.setData(cdata);
dataList=[]


fetch('/json')
  .then(res => res.json())
  .then(data => {
    candleSeries.setData(data);
  })
  .catch(err => log(err))

//   const socket = new WebSocket('ws://localhost:8001');
//
// socket.addEventListener('message', function (event) {
//
//     a=JSON.parse(event.data);
//     log(a);
//     candleSeries.update(a);
// });



//
// const axios = require('axios');
// const getdata = () => {
//     return axios.get('http://127.0.0.1:8000')
//       .then(response => {
//         chartdata=response.data.data;
//         return chartdata
//       })
//       .catch(error => {
//         console.log(error);
//         return error
//       });
// };
//
// getdata().then(function(result) {
//    module.exports={getdata}// "Some User token"
// })
